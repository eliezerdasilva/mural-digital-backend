
const express = require("express");
const { Client } = require("pg");
const app = express();
const cors = require("cors");
// Permitir requisições de qualquer origem (aqui também pode especificar o domínio do frontend(dentro do cors))
app.use(cors());
app.use(express.json());
const PORT = 3000;

// Config do PostgreSQL
const client = new Client({
  user: "postgres",       
  host: "localhost",
  database: "dados_login",
  password: "l040506",    
  port: 6464,
});

//PostgreSQL
client.connect((err) => {
  if (err) {
    console.error("Erro ao conectar ao banco de dados PostgreSQL", err.stack);
    return;
  }
  console.log("Conectado ao banco de dados PostgreSQL");
});

// Middleware para receber JSON
app.use(express.json());
app.use(express.static("public")); // Servir arquivos estáticos

// Endpoint para salvar o usuário
app.post("/save-user", (req, res) => {
  const { email, name, picture } = req.body;

  // Verificar se o usuário já existe
  client.query("SELECT * FROM usuarios WHERE email = $1", [email], (err, result) => {
    if (err) {
      console.error("Erro ao consultar o banco:", err);
      return res.status(500).json({ message: "Erro ao consultar o banco", error: err });
    }

    if (result.rows.length > 0) {
      return res.status(200).json({ message: "Usuário já existe", user: result.rows[0] });
    }

    // Inserir novo usuário
    client.query(
      "INSERT INTO usuarios (email, name, picture) VALUES ($1, $2, $3) RETURNING id",
      [email, name, picture],
      (err, result) => {
        if (err) {
          console.error("Erro ao salvar o usuário:", err);
          return res.status(500).json({ message: "Erro ao salvar o usuário", error: err });
        }

        const newUser = {
          email,
          name,
          picture,
          id: result.rows[0].id,
        };

        res.status(200).json({
          message: "Usuário salvo com sucesso!",
          user: newUser,
        });
      }
    );
  });
});

// Iniciar o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
